
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.datasets import load_diabetes
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import PolynomialFeatures, StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.pipeline import make_pipeline
from sklearn.metrics import mean_squared_error, r2_score

diabetes = load_diabetes()

X = diabetes.data[:, [2]]
y = diabetes.target

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

degrees = [1, 2, 3, 5, 10, 15]

train_errors = []
test_errors = []
r2_scores = []

for degree in degrees:
    model = make_pipeline(
        PolynomialFeatures(degree=degree),
        StandardScaler(),
        LinearRegression()
    )

    model.fit(X_train, y_train)

    train_pred = model.predict(X_train)
    test_pred = model.predict(X_test)

    train_mse = mean_squared_error(y_train, train_pred)
    test_mse = mean_squared_error(y_test, test_pred)
    r2 = r2_score(y_test, test_pred)

    train_errors.append(train_mse)
    test_errors.append(test_mse)
    r2_scores.append(r2)

    print("Polynomial Degree:", degree)
    print("Training MSE:", train_mse)
    print("Testing MSE:", test_mse)
    print("R2 Score:", r2)
    print()

results = pd.DataFrame({
    "Degree": degrees,
    "Training MSE": train_errors,
    "Testing MSE": test_errors,
    "R2 Score": r2_scores
})

print("Comparison of Polynomial Degrees:")
print(results)

plt.figure(figsize=(10, 5))
plt.plot(degrees, train_errors, marker="o", label="Training Error")
plt.plot(degrees, test_errors, marker="o", label="Testing Error")
plt.xlabel("Polynomial Degree")
plt.ylabel("Mean Squared Error")
plt.title("Bias-Variance Trade-off")
plt.legend()
plt.grid()
plt.show()

best_degree = degrees[np.argmin(test_errors)]
print("Best Polynomial Degree:", best_degree)

best_model = make_pipeline(
    PolynomialFeatures(degree=best_degree),
    StandardScaler(),
    LinearRegression()
)

best_model.fit(X_train, y_train)

X_plot = np.linspace(X.min(), X.max(), 200).reshape(-1, 1)
y_plot = best_model.predict(X_plot)

plt.figure(figsize=(10, 5))
plt.scatter(X, y, label="Actual Data")
plt.plot(X_plot, y_plot, color="red", label="Polynomial Regression")
plt.xlabel("BMI")
plt.ylabel("Disease Progression")
plt.title("Polynomial Regression - Best Degree")
plt.legend()
plt.grid()
plt.show()
