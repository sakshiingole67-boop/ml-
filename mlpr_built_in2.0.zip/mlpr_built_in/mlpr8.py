
import pandas as pd
import matplotlib.pyplot as plt

from ucimlrepo import fetch_ucirepo
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import silhouette_score

iris = fetch_ucirepo(id=53)

df = iris.data.features

print("Iris Dataset:")
print(df.head())

print("\nDataset Shape:", df.shape)

X = df.copy()

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

wcss = []
silhouette_scores = []

for k in range(2, 11):

    kmeans = KMeans(
        n_clusters=k,
        init='k-means++',
        n_init=10,
        random_state=42
    )

    labels = kmeans.fit_predict(X_scaled)

    wcss.append(kmeans.inertia_)

    score = silhouette_score(X_scaled, labels)
    silhouette_scores.append(score)

optimal_k = range(2, 11)[
    silhouette_scores.index(max(silhouette_scores))
]

print("\nSilhouette Scores:")

for k, score in zip(range(2, 11), silhouette_scores):
    print("Clusters:", k, "Score:", round(score, 4))

print("\nOptimal Number of Clusters:", optimal_k)

plt.figure(figsize=(7, 5))
plt.plot(range(2, 11), wcss, marker='o')
plt.title("Elbow Method")
plt.xlabel("Number of Clusters")
plt.ylabel("WCSS")
plt.grid()
plt.show()

plt.figure(figsize=(7, 5))
plt.plot(range(2, 11), silhouette_scores, marker='o')
plt.title("Silhouette Method")
plt.xlabel("Number of Clusters")
plt.ylabel("Silhouette Score")
plt.grid()
plt.show()

kmeans = KMeans(
    n_clusters=optimal_k,
    init='k-means++',
    n_init=10,
    random_state=42
)

df['Cluster'] = kmeans.fit_predict(X_scaled)

print("\nClustered Dataset:")
print(df.head(10))

print("\nNumber of Records in Each Cluster:")
print(df['Cluster'].value_counts())

plt.figure(figsize=(8, 5))

plt.scatter(
    df['petal length'],
    df['petal width'],
    c=df['Cluster'],
    cmap='viridis',
    s=50
)

plt.xlabel("Petal Length")
plt.ylabel("Petal Width")
plt.title("Iris Dataset K-Means Clustering")
plt.show()

df.to_csv("iris_clustered.csv", index=False)

print("\nClustered dataset saved successfully!")
