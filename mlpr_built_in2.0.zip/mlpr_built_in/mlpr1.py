
import pandas as pd
import numpy as np
from sklearn.datasets import load_wine
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import LabelEncoder, StandardScaler

wine = load_wine()

df = pd.DataFrame(wine.data, columns=wine.feature_names)
df["target"] = wine.target
df["class"] = df["target"].map(dict(enumerate(wine.target_names)))

print("Original Dataset:")
print(df.head())

print("\nMissing Values:")
print(df.isnull().sum())

df.loc[0, "alcohol"] = np.nan
df.loc[1, "malic_acid"] = np.nan

numerical_columns = wine.feature_names

imputer = SimpleImputer(strategy="mean")
df[numerical_columns] = imputer.fit_transform(df[numerical_columns])

encoder = LabelEncoder()
df["class_encoded"] = encoder.fit_transform(df["class"])

scaler = StandardScaler()
df[numerical_columns] = scaler.fit_transform(df[numerical_columns])

df.drop(columns=["target", "class"], inplace=True)

print("\nMissing Values After Handling:")
print(df.isnull().sum())

print("\nFinal Model-Ready Dataset:")
print(df.head())

print("\nDataset Shape:", df.shape)

print("\nDataset Information:")
print(df.info())
