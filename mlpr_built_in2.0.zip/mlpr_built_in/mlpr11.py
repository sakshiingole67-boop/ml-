
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# Grid World settings
grid_size = 5
start = (0, 0)
goal = (4, 4)
obstacles = [(1, 1), (2, 1), (3, 3)]

actions = [(-1, 0), (1, 0), (0, -1), (0, 1)]
action_symbols = ['↑', '↓', '←', '→']

# Q-table initialization
Q = np.zeros((grid_size, grid_size, len(actions)))

# Hyperparameters
alpha = 0.1
gamma = 0.9
epsilon = 1.0
epsilon_min = 0.01
epsilon_decay = 0.995
episodes = 1500
max_steps = 100

rewards_history = []
steps_history = []
success_history = []

def get_next_state(state, action):
    r, c = state
    dr, dc = actions[action]

    nr = max(0, min(grid_size - 1, r + dr))
    nc = max(0, min(grid_size - 1, c + dc))

    if (nr, nc) in obstacles:
        return state

    return (nr, nc)

# Q-Learning training
for episode in range(episodes):
    state = start
    total_reward = 0
    success = False

    for step in range(max_steps):
        r, c = state

        # Epsilon-greedy exploration-exploitation
        if np.random.random() < epsilon:
            action = np.random.randint(len(actions))
        else:
            action = np.argmax(Q[r, c])

        next_state = get_next_state(state, action)
        nr, nc = next_state

        if next_state == goal:
            reward = 100
            success = True
        elif next_state == state:
            reward = -5
        else:
            reward = -1

        # Q-Learning update rule
        Q[r, c, action] += alpha * (
            reward + gamma * np.max(Q[nr, nc]) - Q[r, c, action]
        )

        state = next_state
        total_reward += reward

        if success:
            break

    rewards_history.append(total_reward)
    steps_history.append(step + 1)
    success_history.append(int(success))

    epsilon = max(epsilon_min, epsilon * epsilon_decay)

# Display learned optimal policy
policy = np.full((grid_size, grid_size), '·', dtype='<U2')

for r in range(grid_size):
    for c in range(grid_size):
        if (r, c) == start:
            policy[r, c] = 'S'
        elif (r, c) == goal:
            policy[r, c] = 'G'
        elif (r, c) in obstacles:
            policy[r, c] = 'X'
        else:
            policy[r, c] = action_symbols[np.argmax(Q[r, c])]

print("Learned Optimal Policy:")
print(policy)

print("\nFinal Epsilon:", round(epsilon, 4))
print("Success Rate (last 100 episodes):",
      round(np.mean(success_history[-100:]) * 100, 2), "%")
print("Average Steps (last 100 episodes):",
      round(np.mean(steps_history[-100:]), 2))
print("Average Reward (last 100 episodes):",
      round(np.mean(rewards_history[-100:]), 2))

# Visualization 1: Reward per episode
plt.figure(figsize=(10, 4))
plt.plot(rewards_history, alpha=0.35, label="Episode Reward")
plt.plot(np.convolve(rewards_history, np.ones(50)/50, mode='valid'),
         label="50-Episode Average")
plt.title("Q-Learning: Reward per Episode")
plt.xlabel("Episode")
plt.ylabel("Total Reward")
plt.legend()
plt.grid()
plt.show()

# Visualization 2: Steps per episode
plt.figure(figsize=(10, 4))
plt.plot(steps_history, alpha=0.4, label="Steps")
plt.plot(np.convolve(steps_history, np.ones(50)/50, mode='valid'),
         label="50-Episode Average")
plt.title("Steps Required to Reach Goal")
plt.xlabel("Episode")
plt.ylabel("Steps")
plt.legend()
plt.grid()
plt.show()

# Visualization 3: Success rate
window = 100
success_rate = np.convolve(
    success_history, np.ones(window)/window, mode='valid'
) * 100

plt.figure(figsize=(10, 4))
plt.plot(success_rate)
plt.title("Learning Performance: Success Rate")
plt.xlabel("Episode")
plt.ylabel("Success Rate (%)")
plt.grid()
plt.show()

# Visualization 4: Q-table heatmap
max_q = np.max(Q, axis=2)
max_q[np.array(obstacles)[:, 0], np.array(obstacles)[:, 1]] = np.nan

plt.figure(figsize=(6, 5))
sns.heatmap(max_q, annot=True, fmt=".1f", cmap="YlGnBu")
plt.title("Learned State Values (Maximum Q-Value)")
plt.xlabel("Column")
plt.ylabel("Row")
plt.show()
