
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.datasets import load_diabetes
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression, Ridge, Lasso
from sklearn.metrics import mean_squared_error, r2_score

diabetes = load_diabetes()

X = pd.DataFrame(diabetes.data, columns=diabetes.feature_names)
y = diabetes.target

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

scaler = StandardScaler()

X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

models = {
    "Linear Regression": LinearRegression(),
    "Ridge Regression": Ridge(alpha=1.0),
    "Lasso Regression": Lasso(alpha=0.1)
}

results = []

for name, model in models.items():

    model.fit(X_train_scaled, y_train)

    train_pred = model.predict(X_train_scaled)
    test_pred = model.predict(X_test_scaled)

    train_mse = mean_squared_error(y_train, train_pred)
    test_mse = mean_squared_error(y_test, test_pred)

    train_r2 = r2_score(y_train, train_pred)
    test_r2 = r2_score(y_test, test_pred)

    results.append([
        name, train_mse, test_mse, train_r2, test_r2
    ])

    print("\n", name)
    print("Training MSE:", train_mse)
    print("Testing MSE:", test_mse)
    print("Training R2 Score:", train_r2)
    print("Testing R2 Score:", test_r2)

results_df = pd.DataFrame(
    results,
    columns=["Model", "Training MSE", "Testing MSE",
             "Training R2", "Testing R2"]
)

print("\nModel Comparison:")
print(results_df)

plt.figure(figsize=(9, 5))
plt.bar(results_df["Model"], results_df["Testing MSE"])
plt.xlabel("Regression Models")
plt.ylabel("Testing Mean Squared Error")
plt.title("Comparison of Regression Models")
plt.show()

plt.figure(figsize=(9, 5))
plt.bar(results_df["Model"], results_df["Testing R2"])
plt.xlabel("Regression Models")
plt.ylabel("Testing R2 Score")
plt.title("R2 Score Comparison")
plt.show()

ridge = Ridge(alpha=1.0)
lasso = Lasso(alpha=0.1)

ridge.fit(X_train_scaled, y_train)
lasso.fit(X_train_scaled, y_train)

coefficient_df = pd.DataFrame({
    "Feature": X.columns,
    "Ridge Coefficient": ridge.coef_,
    "Lasso Coefficient": lasso.coef_
})

print("\nCoefficient Comparison:")
print(coefficient_df)

print("\nNumber of Zero Lasso Coefficients:",
      np.sum(lasso.coef_ == 0))
