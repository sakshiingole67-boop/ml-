import pandas as pd
import numpy as np
import time

from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report

# Load dataset
data = load_breast_cancer()

X = data.data
y = data.target

print("Original Shape:", X.shape)

# Split dataset
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# Feature Scaling
scaler = StandardScaler()

X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Logistic Regression without LDA
start = time.time()

model_original = LogisticRegression(max_iter=1000)
model_original.fit(X_train_scaled, y_train)

prediction_original = model_original.predict(X_test_scaled)

end = time.time()

accuracy_original = accuracy_score(y_test, prediction_original)
time_original = end - start

# Apply LDA
lda = LinearDiscriminantAnalysis(n_components=1)

X_train_lda = lda.fit_transform(X_train_scaled, y_train)
X_test_lda = lda.transform(X_test_scaled)

print("Reduced Shape:", X_train_lda.shape)

# Logistic Regression with LDA
start = time.time()

model_lda = LogisticRegression()
model_lda.fit(X_train_lda, y_train)

prediction_lda = model_lda.predict(X_test_lda)

end = time.time()

accuracy_lda = accuracy_score(y_test, prediction_lda)
time_lda = end - start

# Results
print("\nComparison Results")
print("Original Features :", X_train_scaled.shape[1])
print("Reduced Features :", X_train_lda.shape[1])

print("Accuracy Before LDA :", accuracy_original)
print("Accuracy After LDA :", accuracy_lda)

print("Training Time Before LDA :", time_original)
print("Training Time After LDA :", time_lda)

# Classification Reports
print("\nClassification Report Without LDA")
print(classification_report(y_test, prediction_original))

print("\nClassification Report With LDA")
print(classification_report(y_test, prediction_lda))