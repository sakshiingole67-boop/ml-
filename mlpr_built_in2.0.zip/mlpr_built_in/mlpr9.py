import pandas as pd
import matplotlib.pyplot as plt

from sklearn.datasets import load_iris
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import DBSCAN

# Load Iris dataset
iris = load_iris()

X = pd.DataFrame(
    iris.data,
    columns=iris.feature_names
)

# Select two features for visualization
X = X[[
    "petal length (cm)",
    "petal width (cm)"
]]

# Standardize the data
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Apply DBSCAN
dbscan = DBSCAN(eps=0.5, min_samples=5)

labels = dbscan.fit_predict(X_scaled)

# Add cluster labels
X["Cluster"] = labels

print("Cluster Labels:")
print(X["Cluster"].value_counts().sort_index())

# Number of clusters
n_clusters = len(set(labels)) - (1 if -1 in labels else 0)

# Number of noise points
n_noise = list(labels).count(-1)

print("\nNumber of Clusters:", n_clusters)
print("Number of Noise Points:", n_noise)

# Display data
print("\nClustered Data:")
print(X.head(10))

# Plot clusters
plt.figure(figsize=(10, 6))

plt.scatter(
    X.iloc[:, 0],
    X.iloc[:, 1],
    c=labels,
    cmap="viridis",
    s=60
)

plt.xlabel("Petal Length (cm)")
plt.ylabel("Petal Width (cm)")
plt.title("DBSCAN Clustering on Iris Dataset")
plt.colorbar(label="Cluster")
plt.grid(True)

plt.show()